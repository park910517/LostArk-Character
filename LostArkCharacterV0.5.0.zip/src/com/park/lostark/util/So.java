package com.park.lostark.util;

public class So {
	public static void pl(String s) {
		System.out.println(s);

	}
	
	public static void p(String s) {
		System.out.print(s);
	}
}
