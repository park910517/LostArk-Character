package com.park.lostark;

public class Main {

	public static void main(String[] args) {
		
			LostArk lostark = new LostArk();
			lostark.run();
			

	}

}
