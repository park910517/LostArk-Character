package com.park.lostark.display;

public class Title {

		public static final String TITLE = "**************************\n" + "   LOSTARK 보유 캐릭터관리\n" + "**************************\n";
		public static final String ADD = "--------------------------------\n" + "LOSTARK 캐릭터 추가(뒤로가기는 back입력)\n" + "--------------------------------";
		public static final String DEL = "--------------------------------\n" + "LOSTARK 캐릭터 삭제(뒤로가기는 back입력)\n" + "--------------------------------";
		public static final String EDIT = "---------------------------\n" + "    LOSTARK 캐릭터정보 수정\n" + "---------------------------";
		public static final String LIST = "-------------------------------------\n" + "         LOSTARK 캐릭터 목록\n" + "-------------------------------------";
}
