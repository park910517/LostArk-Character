package com.park.lostark.display;

public class Title {

		public static final String TITLE = "**************************\n" + "   LOSTARK 보유 캐릭터관리\n" + "**************************\n";
		public static final String ADD = "--------------------------------\n" + "LOSTARK 캐릭터 추가(뒤로가기는 back입력)\n" + "--------------------------------";
		public static final String DEL = "--------------------------------\n" + "LOSTARK 캐릭터 삭제(뒤로가기는 back입력)\n" + "--------------------------------";
		public static final String EDIT = "---------------------------\n" + "    LOSTARK 캐릭터정보 수정\n" + "---------------------------";
		public static final String LIST = "-------------------------------------\n" + "         LOSTARK 캐릭터 목록\n" + "-------------------------------------";
		public static final String SEARCH = "-------------------------------------\n" + "         LOSTARK 캐릭터 검색\n" + "-------------------------------------";
		public static final String ALLGOLD = "-------------------------------------\n" + "LOSTARK 6캐릭 주간 총 골드 수익\n" + "-------------------------------------";
		public static final String GOLDNAME = "-------------------------------------\n" + "LOSTARK 캐릭터 주간 골드 수익\n" + "-------------------------------------";
}
